import React, { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';

export default function Ui({ children }) {


    return (
        <>
            {children}
        </>
    )
}